<?php

class Services_Twilio_Rest_Transcription
    extends Services_Twilio_InstanceResource
{
}
