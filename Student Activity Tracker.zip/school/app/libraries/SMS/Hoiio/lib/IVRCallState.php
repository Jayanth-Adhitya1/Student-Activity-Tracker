<?php

class IVRCallState {
    const RINGING = "ringing";
    const ONGOING = "ongoing";
    const ENDED = "ended";
}
