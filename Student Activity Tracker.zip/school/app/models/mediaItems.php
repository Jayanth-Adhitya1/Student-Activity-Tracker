<?php
class mediaItems extends Eloquent {
	public $timestamps = false;
	protected $table = 'mediaItems';
}